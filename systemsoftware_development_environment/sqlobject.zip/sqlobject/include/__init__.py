"""
This directory includes third-party software, or software that is
distributed separately, that may not be installed on this computer.
"""
